const express = require('express');

const app = express();

const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware')
app.use(awsServerlessExpressMiddleware.eventContext())


app.get('/',(req,res)=>{
    res.send("Hello World");
})


module.exports = app;